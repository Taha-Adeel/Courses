To compile the rw source code, run the following command in the terminal (Command line)
	g++ -o Assn5-rw-CS20BTECH11052 Assn5-rw-CS20BTECH11052.cpp -lpthread

To compile the frw source code, run the following command in the terminal (Command line)
	g++ -o Assn5-frw-CS20BTECH11052 Assn5-frw-CS20BTECH11052.cpp -lpthread


To run the executable simulating the reader writer problems, run the executable name in the terminal (Command line), for example
	./Assn5-rw-CS20BTECH11052


These programs will read the input from "inp-params.txt" and log the events of the reader writer problem simulation into the appropriate log and stats files.