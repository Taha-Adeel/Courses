#include "types.h"
#include "stat.h"
#include "user.h"


int main(){
	setPriority(5);

	int num_processes = 5;
	
	for(int i=0; i < num_processes; ++i){
		if(fork()==0){
			int priority = i%10;
			setPriority(priority);
				printf(1,"Process with priority: %d was executed\n", priority);
		}
		else{
			sleep(10);// to make the parent process wait
		}
	}

	return 0;
}