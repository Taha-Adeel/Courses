#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
	int priority;
	if(argc != 2){
		printf(1, "Error: Invalid priority given.\n");
		exit();
	}

	priority = atoi(argv[1]);
	if(priority < 0 || priority > 9){
		printf(1, "Error: Invalid priority given.\n");
		exit();
	}
	setPriority(priority);

	exit();
}