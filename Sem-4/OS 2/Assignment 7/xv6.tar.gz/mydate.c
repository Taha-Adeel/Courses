#include "types.h"
#include "stat.h"
#include "user.h"
#include "date.h"

int main(int argc, char *argv[])
{
	struct rtcdate r;
	if (date(&r)) {
		printf(2, "date failed\n");
		exit();
	}

	printf(1, "Year:\t %d\n", r.year);
	printf(1, "Month:\t %d\n", r.month);
	printf(1, "Date:\t %d\n", r.day);
	printf(1, "Hour:\t %d\n", r.hour);
	printf(1, "Minute:\t %d\n", r.minute);
	printf(1, "Second:\t %d\n", r.second);

	exit();
}