#include<stdio.h>
#include<stdlib.h>
#include<seven_segment.h>

int main()
{
	init();
	while(1)
	{
		select(1);
		write(strtol(11110011));
		delay(40);
		select(20);
		write(strtol(01100000));
		delay(40);
		select(30);
		write(strtol(01100110));
		delay(40);
	}
}
