# README

* To run the codes in basic and star, extract and copy the folders to /home/p4/tutorials/exercises 

* Run make run (You are now on the mininet promt)

----

For ./basic

* Run 'xterm h1' and 'xterm h2' to open the client and server nodes respectively

* In h2's terminal run 'bash h2-arp.sh' and 'python server.py'. The IP addresses are harcoded into the code, so there is no need for user input.

* In h1's terminal run 'bash h1-arp.sh' and 'python client.py'. The requests being made to the server are hardcoded in the client.py file (All 6 key value pairs are first PUT into the server, then we GET and delete Key1). To send other requests, add them to client.py


----

For ./star

* Run 'xterm h1', 'xterm h2' and 'xterm h3' to open the client, cache, and server nodes respectively

* In each node's terminal, run their corresponding bash file and python file.

* The IP Address's of the nodes are hardcoded in their respective files, hence there is no need for user input

* Similarly, the requests to the server(cache) are also hardcoded in client.py, from where they can be modified.