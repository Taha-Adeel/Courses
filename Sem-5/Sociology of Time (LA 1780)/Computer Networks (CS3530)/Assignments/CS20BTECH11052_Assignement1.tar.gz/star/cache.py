import socket

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).
cache_dict = {}

s_cache = socket.socket()
print ("Cache socket successfully created")

cache_ip = "10.0.1.2"
cache_port = 12333

s_cache.bind((cache_ip, cache_port))
print ("Cache socket binded to %s" %(cache_port))

server_ip = "10.0.1.3"
server_port = 12346

s_server = socket.socket()
s_server.connect((server_ip, server_port))
print("Succesfully connected to " + server_ip)

s_cache.listen(5)
print ("Cache socket is listening")

http_ok = "HTTP/1.1 200 OK\r\n"
http_bad_request = "HTTP/1.1 400 Bad Request\r\n"
http_not_found = "HTTP/1.1 404 Not Found\r\n"

while True:
    client, addr = s_cache.accept()
    print ('Got connection from', addr )
    while True:
        recvmsg = client.recv(1024).decode()
        if recvmsg == "": break
        print('\nCache server received ' + recvmsg.strip())
    
        request_type = recvmsg.split()[0]

        if request_type == "GET":
            if recvmsg.split()[1].find("?request=") == -1:
                client.send((http_bad_request + recvmsg + "\r\n\r\n").encode())
            else:
                request_key = recvmsg.split()[1].split("?request=")[1]
                print("Client requested for key: " + request_key)
                if request_key in cache_dict:
                    client.send((http_ok + cache_dict[request_key] + "\r\n\r\n").encode())
                else:
                    print('Cache sent request to server ' + recvmsg.strip())
                    s_server.send(recvmsg.encode())
                    server_response = s_server.recv(1024).decode()
                    print ('Cache received ' + server_response.strip())
                    client.send(server_response.encode())
                    if http_ok in server_response:
                        cache_dict[request_key] = server_response.split("\r\n")[1].strip()
        
        elif request_type == "PUT":
            print('Cache sent request to server ' + recvmsg.strip())
            s_server.send(recvmsg.encode())
            server_response = s_server.recv(1024).decode()
            print ('Cache received ' + server_response.strip())
            client.send(server_response.encode())

        else:
            client.send((http_bad_request + recvmsg).encode())
            
    ##################
    # client.close()

s_server.close()