import socket

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).
key_value_dict = {}

s = socket.socket()
print ("Socket successfully created")

server_ip = "10.0.1.2"
server_port = 12346

s.bind((server_ip, server_port))
print ("socket binded to %s" %server_port)

s.listen(5)
print ("socket is listening")

http_ok = "HTTP/1.1 200 OK\r\n"
http_bad_request = "HTTP/1.1 400 Bad Request\r\n"
http_not_found = "HTTP/1.1 404 Not Found\r\n"

while True:
    client, addr = s.accept()
    print ('Got connection from', addr )
    while True:
        recvmsg = client.recv(1024).decode()
        if recvmsg == "": break
        print('\nServer received ' + recvmsg.strip())
    
        #Write your code here
        #1. Uncomment c.send 
        #2. Parse the received HTTP request
        #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
        #4. Send response
    
        request_type = recvmsg.split()[0]

        if request_type == "GET":
            if recvmsg.split()[1].find("?request=") == -1:
                client.send((http_bad_request + recvmsg + "\r\n\r\n").encode())
            else:
                request_key = recvmsg.split()[1].split("?request=")[1]
                print("Client requested for key: " + request_key)
                if request_key in key_value_dict:
                    client.send((http_ok + key_value_dict[request_key] + "\r\n\r\n").encode())
                else:
                    client.send((http_not_found + request_key + " key not found" + "\r\n\r\n").encode())
        
        elif request_type == "PUT":
            request_key = recvmsg.split()[1].split("/")[-2]
            request_val = recvmsg.split()[1].split("/")[-1]
            print("Client put key value pair = {" + request_key + ", " + request_val + "}")
            if request_key in key_value_dict:
                client.send((http_bad_request + request_key + " already exists with the server" + "\r\n\r\n").encode())
            else:
                key_value_dict[request_key] = request_val
                client.send((http_ok + "\r\n").encode())

        elif request_type == "DELETE":
            request_key = recvmsg.split()[1].split("/")[-1]
            print("Client delete key value pair with key: " + request_key)
            if request_key in key_value_dict:
                del key_value_dict[request_key]
                client.send((http_ok + "\r\n").encode())
            else:
                client.send((http_not_found + request_key + "doesnt exist" + "\r\n\r\n").encode())

        else:
            client.send((http_bad_request + recvmsg).encode())
            
    ##################
    client.close()
  
    #break