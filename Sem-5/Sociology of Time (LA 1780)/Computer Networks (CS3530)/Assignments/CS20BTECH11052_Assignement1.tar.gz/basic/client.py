import socket

server_ip = "10.0.1.2"
server_port = 12346
s = socket.socket()
s.connect((server_ip, server_port))

print("Succesfully connected to " + server_ip)

#Write your code here:
#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
#2. Add the code to parse the response you get from the server.

def request_msg(request_type, *parameters):
	if request_type == "GET":
		return "GET /assignment1?request=" + parameters[0] + " HTTP/1.1"
	if request_type == "PUT":
		return "PUT /assignement1/" + parameters[0] + "/" + parameters[1] + " HTTP/1.1"
	if request_type == "DELETE":
		return "DELETE /assignement1/" + parameters[0] + " HTTP/1.1"

def request(msg):
	print('\nClient sent request ' + msg)
	s.send((msg + "\r\n\r\n").encode())
	print ('Client received ' + s.recv(1024).decode().strip() + '\n')

# Populating the servers key value pairs (4E)
request(request_msg("PUT", "Key1", "Val1"))
request(request_msg("PUT", "Key2", "Val2"))
request(request_msg("PUT", "Key3", "Val3"))
request(request_msg("PUT", "Key4", "Val4"))
request(request_msg("PUT", "Key5", "Val5"))
request(request_msg("PUT", "Key6", "Val6"))

# Test 1 (4F)
request(request_msg("GET", "Key1"))

# Test 2 (4G)
request(request_msg("DELETE", "Key1"))

s.close()