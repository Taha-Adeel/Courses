import socket
import os

recieverIP = "10.0.0.2"
recieverPort   = 20002
bufferSize  = 1024 # Message Buffer Size

# Create a UDP socket
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind socket to localIP and localPort
socket_udp.bind((recieverIP, recieverPort))
print("UDP socket created successfully....." )

# Read the filename from the sender
filename, senderAddress = socket_udp.recvfrom(bufferSize)
filename = filename.decode()
basename = os.path.splitext(filename)[0]
filename = basename + "_reciever_copy" + ".jpg"

# Open the file and read it in chunks using the Go Back N protocol
with open(filename, 'wb') as f:
    cur_packet = 0;
    lastSuccessfulPacket = "0".encode()
    while True:
        # Recieve the packet from the sender
        packet, senderAddress = socket_udp.recvfrom(bufferSize)
        seqNumber = int.from_bytes(packet[:2], byteorder='big')
        lastPacket = bool.from_bytes(packet[2:3], byteorder='big')
        data = packet[3:]

        # Check if the packet is the next packet in the sequence
        if seqNumber == cur_packet:
            print("Packet: {} recieved successfully".format(seqNumber))
            f.write(data)
            lastSuccessfulPacket = str(cur_packet).encode()
            socket_udp.sendto(lastSuccessfulPacket, senderAddress)
            cur_packet += 1
        else:
            print("Recieved packet: {} out of order. Expecting packet: {}".format(seqNumber, cur_packet))
            socket_udp.sendto(lastSuccessfulPacket, senderAddress) # Send the last ACK again
            lastPacket = False

        # Break if last packet recieved
        if lastPacket: break

print("File {} recieved successfully".format(filename))
socket_udp.close()