import socket
from threading import Lock, Thread
import time
import sys

senderIP = "10.0.0.1"
senderPort = 20001
recieverAddressPort = ("10.0.0.2", 20002)
bufferSize = 1024 # Message Buffer Size

headerSize = 3 # 1st 2 bytes are seq number and 3rd byte is flag to represent last package
chunkSize = bufferSize - headerSize # The chunksize in which the file data is transmitted
N = 32 # Window size
timeout = 0.100 # timeout in seconds

# Create a UDP socket at reciever side
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
socket_udp.settimeout(timeout)

# filename = input("Please enter filename of file to transmit to the reciever: ")
filename = "testFile.jpg"
bytesToSend = str.encode(filename)
socket_udp.sendto(bytesToSend, recieverAddressPort)

# Read the files in chunks and store the chunks in a list, with its index as its sequence number
chunkList = []
with open(filename, 'rb') as f:
	data = f.read(chunkSize)
	while data:
		chunkList.append(data)
		data = f.read(chunkSize)

# Send the chunks in the list using the Go Back N protocol
mutex_lock = Lock()
curSeqNumber = 0
leftWindowSeqNumber = 0

# Function to send the chunks in the list
def sendPackets():
    global curSeqNumber
    global leftWindowSeqNumber
    while leftWindowSeqNumber < len(chunkList):
        mutex_lock.acquire()
        while curSeqNumber < len(chunkList) and curSeqNumber < leftWindowSeqNumber + N:
            # Create the packet with the sequence number and the data
            seqNumber = curSeqNumber.to_bytes(2, byteorder='big')
            lastPacket = (curSeqNumber == len(chunkList) - 1).to_bytes(1, byteorder='big')
            packet = seqNumber + lastPacket + chunkList[curSeqNumber]

            # Send the packet to the reciever
            print("Sending Packet: {}".format(curSeqNumber))
            socket_udp.sendto(packet, recieverAddressPort)

            curSeqNumber += 1
        mutex_lock.release()

# Function to recieve the acknowledgements from the reciever
def recieveAcks():
    global curSeqNumber
    global leftWindowSeqNumber
    while leftWindowSeqNumber < len(chunkList):
        try:
            # Recieve the acknowledgement from the reciever
            msgFromReciever = socket_udp.recvfrom(bufferSize)[0]
            lastSuccessfulPacket = int(msgFromReciever.decode())
            print("Recieved Acknowledgement: {}".format(lastSuccessfulPacket))

            # If the acknowledgement is for the current packet, move the left window
            mutex_lock.acquire()
            if lastSuccessfulPacket >= leftWindowSeqNumber:
                leftWindowSeqNumber = lastSuccessfulPacket + 1
            mutex_lock.release()
        except socket.timeout:
            mutex_lock.acquire()
            curSeqNumber = leftWindowSeqNumber
            mutex_lock.release()


startTime = time.time()

# Create and start the threads
sendThread = Thread(target = sendPackets)
recieveThread = Thread(target = recieveAcks)

sendThread.start()
recieveThread.start()

# Wait for the threads to finish
sendThread.join()
recieveThread.join()

# All packets sent successfully
endTime = time.time()
transferTime = endTime - startTime
throughput = (len(chunkList)*chunkSize/1024)/transferTime

print("File sent successfully")
print("Transfer time: {} seconds".format(transferTime))
print("Throughput: {} KB/s".format(throughput))