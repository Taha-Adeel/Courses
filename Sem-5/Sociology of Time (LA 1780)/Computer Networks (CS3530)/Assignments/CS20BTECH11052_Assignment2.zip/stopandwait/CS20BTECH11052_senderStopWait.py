import select
import socket
import time
import sys

senderIP = "10.0.0.1"
senderPort   = 20001
recieverAddressPort = ("10.0.0.2", 20002)
bufferSize  = 1024 # Message Buffer Size
headerSize = 3 # 1st 2 bytes are seq number and 3rd byte is flag to represent last package
chunkSize = bufferSize - headerSize # The chunksize in which the file data is transmitted
timeout = 0.02 # timeout in seconds 

# Create a UDP socket at reciever side
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# filename = input("Please enter filename of file to transmit to the reciever: ")
filename = "testFile.jpg"
bytesToSend = str.encode(filename)
socket_udp.sendto(bytesToSend, recieverAddressPort)

# Wait for acknowledgement message of having recieved filename from reciever
msgFromReciever = socket_udp.recvfrom(bufferSize)
msg = "Message from Reciever:" + msgFromReciever[0].decode()
# print(msg)

# Read the files in chunks and store the chunks in a list, with its index as its sequence number
chunkList = []
with open(filename, 'rb') as f:
	data = f.read(chunkSize)
	while data:
		chunkList.append(data)
		data = f.read(chunkSize)

# Send the file to the reciever in chunks with a Stop and Wait protocol
seqNumber = 0
startTime = time.time()
retransmissionsCount = 0
while seqNumber < len(chunkList):
	# Create header with 1st 2 bytes as seq number and 3rd byte as flag to represent last packet
	header = seqNumber.to_bytes(2, byteorder='big') \
		+ (seqNumber == len(chunkList)-1).to_bytes(1, byteorder='big')
	chunk = chunkList[seqNumber]
	packet = header + chunk

	# Send the packet to the reciever
	socket_udp.sendto(packet, recieverAddressPort)

	# Stop and Wait for timeout seconds for acknowledgement from the reciever
	ready = select.select([socket_udp], [], [], timeout)
	if ready[0]:
		# Recieve the acknowledgement from the reciever
		msgFromReciever, recieverAddressPort = socket_udp.recvfrom(bufferSize)

		# seqNumber%2 represents the ACK flag that the reciever should transmit back to acknowledge the current packet
		ack = int(msgFromReciever.decode())
		if ack == seqNumber%2: 
			# print("Packet with sequence number {} successfully transmitted".format(seqNumber))
			seqNumber += 1
		else: 
			# If the acknowledgement is not for the current packet, resend the packet
			# print("Packet with sequence number {} not recieved, retransmitting packet".format(seqNumber))
			retransmissionsCount += 1
	else:
		# If no acknowledgement is recieved, resend the packet
		# print("Packet with sequence number {} not recieved, retransmitting packet".format(seqNumber))
		retransmissionsCount += 1

# All packets sent successfully
endTime = time.time()
transferTime = endTime - startTime
throughput = (len(chunkList)*chunkSize/1024)/transferTime

print("File sent successfully")
print("Timeout: {} ms".format(timeout*1000))
print("Number of retransmissions: {}".format(retransmissionsCount))
print("Transfer time: {} seconds".format(transferTime))
print("Throughput: {} KB/s".format(throughput))