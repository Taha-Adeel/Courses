#! /bin/bash

RETRANSMISSION_TIMEOUTS=(5 10 15 20 25 30 40 50 75 100)
NUMBER_OF_RUNS=5
AVERAGE_RETRANSMISSIONS=()
AVERAGE_THROUGHPUTS=()

for i in "${RETRANSMISSION_TIMEOUTS[@]}"; do
	TOTAL_RETRANSMISSIONS=0
	TOTAL_THROUGHPUT=0
	echo "Running test with retransmission timeout $i" >> output.txt
	for j in $(seq 1 $NUMBER_OF_RUNS); do
		OUTPUT=($(python3 CS20BTECH11052_senderStopWait.py $i))
		TOTAL_RETRANSMISSIONS=$(($TOTAL_RETRANSMISSIONS + ${OUTPUT[0]}))
		TOTAL_THROUGHPUT=$(bc <<< "$TOTAL_THROUGHPUT + ${OUTPUT[1]}")
		echo -e "\tRetransmissions: ${OUTPUT[0]} \t Throughput: ${OUTPUT[1]} " >> output.txt
	done
	AVERAGE_RETRANSMISSION=$(bc <<< "scale=2; $TOTAL_RETRANSMISSIONS / $NUMBER_OF_RUNS")
	AVERAGE_THROUGHPUT=$(bc <<< "scale=2; $TOTAL_THROUGHPUT / $NUMBER_OF_RUNS")
	echo -e "Retransmission timeout $i: \n\tAverage retransmission is $AVERAGE_RETRANSMISSION\n\tAverage throughput is $AVERAGE_THROUGHPUT\n" >> output.txt
done