#include <stdio.h>

char* even_or_odd(int n){
    if(n%2 == 0) return "even";
    else return "odd";
}

int main(){
    int n = 10;

    printf("%d is %s\n", n, even_or_odd(n)); 

    return 0;
}