#include <iostream>
using namespace std;

int main()
{
    size_t radius = 5;
    size_t diameter = 2*radius;
    float perimeter = diameter * 3.1416f;
    float area = radius * radius * 3.1416f;

    int a = 8;
    int b = -3 + a / 4;
    int c = b * ( 200 / a + 2 ) -  a;

    c = b * 4;
    if (c < 10) {
        c = c - 10;
    }

    int count = 0;
    for(int i=0; i<10; i++)
    {
        count += (i+1);
    }

    cout << count;

    return 0;
}