#include <iostream>
using namespace std;

int sum2 (int a, int b)
{
    return a + b;
}

float sum3 (float a, float b, float c)
{
    return a + b + c;
}

double mul2 (int a, double b)
{
    double t = a * b;
    return t;
}

int mul3 (char a, int b, int c)
{
    int t = a;
    return a * b * c;
}

int main()
{
    cout << mul3('2', 1, 4) << endl;
    cout << sum2(-7, 8) << endl;
    cout << mul2(3, 4.2) << endl;
    cout << sum3(1.2, 1.5, 1.7) << endl;
    return 0;
}