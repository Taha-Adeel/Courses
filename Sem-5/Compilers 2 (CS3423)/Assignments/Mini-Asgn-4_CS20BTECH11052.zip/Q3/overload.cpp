#include <iostream>
using namespace std;

int multiply(int num) 
{
   int product = num * num;
   return product;
}

double multiply(double num) 
{
   return num * num;
}

int multiply(char num)
{
    int temp = num;
    return temp * temp;
}


int main()
{
    cout << "char" << " " << multiply('a') << endl;
    cout << "int" << " " << multiply(10) << endl;
    cout << "double" << " " << multiply(5.3) << endl;
    return 0;
}