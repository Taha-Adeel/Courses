#include <iostream>
using namespace std;

int main()
{
    int a = 20;
    int b = 10;
    cout << "Values of a and b in outermost scope are: " << a << ", " << b << endl;
    if(true)
    {
        int a = 7;
        int b = 2;
        cout << "Values of a and b in inner scope are: " << a << ", " << b << endl;
        a += 5;
        b *= 3;
        cout << "Values of a and b in inner scope after updation are: " << a << ", " << b << endl;
    }
    cout << "Values of a and b again in outermost scope are: " << a << ", " << b << endl;
    return 0;
}