#!/bin/bash

targets=('Q2' 'Q3' 'Q4')
llvm_bin_path='../llvmasgn/llvm-project/build/bin'

if [[ "$1" == "all" || "$1" == "" ]] ; then
    for i in "${targets[@]}" ; do
        "$0" "$i"
        echo ""
    done
    exit 0
fi

if [[ "$1" == "clean" ]] ; then
    echo "Removing all generated files"
    find . -name "*.ll" -type f -delete
    find . -name "*.s" -type f -delete
    find . -name "*.i" -type f -delete
    find . -name "*.bc" -type f -delete
    find . -name "*.native" -type f -delete
    find . -name "*.dot" -type f -delete
    find . -type f -executable -exec sh -c "file -i '{}' | grep -q 'x-executable; charset=binary'" \; -print | xargs rm -f
    exit 0
fi

if [[ "$1" == "Q2" ]] ; then
    echo "Generating LLVM-IR for sample codes for Q2"
    cd Q2
    for i in *.cpp ; do
        echo " "
        echo "Generating IR code for $i"
        ../"$llvm_bin_path"/clang++ -O2 -emit-llvm $i -S -o ${i%.cpp}.ll
        echo "Compiling $i"
        ../"$llvm_bin_path"/clang++ $i -o ${i%.cpp}
        echo "Running $i"
        ./${i%.cpp}
    done
    exit 0
fi

if [[ "$1" == "Q3" ]] ; then
    echo "Generating Assembly language codes for Q3"
    cd Q3
    for i in *.cpp ; do
        echo " "
        echo "Generating Assembly code for $i"
        ../"$llvm_bin_path"/clang++ $i -S -o ${i%.cpp}.s
        echo "Compiling $i"
        ../"$llvm_bin_path"/clang++ $i -o ${i%.cpp}
        echo "Running $i"
        ./${i%.cpp}
    done
    exit 0
fi

if [[ "$1" == "Q4" ]] ; then
    echo " "
    echo "Exploring compiler toolchain and options for Q4"
    cd Q4
    if [[ "$2" == "a" || "$2" == "" ]] ; then
        echo "Performing the compilation stage wise for Q4 (a)"
        cd a
        for i in *.cpp ; do
            echo "Running preprocessing stage on $i to generate ${i%.cpp}.i"
            ../../"$llvm_bin_path"/clang++ $i -E -o "${i%.cpp}.i"

            echo "Generating LLVM IR from ${i%.cpp}.i : Bitcode IR -> ${i%.cpp}.bc       Textual IR -> ${i%.cpp}.ll"
            ../../"$llvm_bin_path"/clang++ -emit-llvm $i -S -o ${i%.cpp}.ll
            ../../"$llvm_bin_path"/clang++ -emit-llvm $i -c -o ${i%.cpp}.bc

            echo "Compiling ${i%.cpp}.bc to native assembly (${i%.cpp}.s) using the LLC code generator"
            ../../"$llvm_bin_path"/llc ${i%.cpp}.bc -o ${i%.cpp}.s

            echo "Assembling the native assembly language file(${i%.cpp}.s) into a program(${i%.cpp}.native)"
            g++ $i -o ${i%.cpp}.native

            echo "Running ${i%.cpp}.native"
            time ./${i%.cpp}.native

            echo " "

            echo "Generating Optimized(-O3) LLVM IR from ${i%.cpp}.i : Bitcode IR -> ${i%.cpp}.bc       Textual IR -> ${i%.cpp}.ll"
            ../../"$llvm_bin_path"/clang++ -emit-llvm $i -S -o ${i%.cpp}.ll
            ../../"$llvm_bin_path"/clang++ -emit-llvm $i -c -o ${i%.cpp}.bc

            echo "Compiling ${i%.cpp}.bc to native assembly (${i%.cpp}.s) using the LLC code generator"
            ../../"$llvm_bin_path"/llc ${i%.cpp}.bc -o ${i%.cpp}.s

            echo "Assembling the native assembly language file(${i%.cpp}.s) into a program(${i%.cpp}.native)"
            g++ $i -o ${i%.cpp}.native

            echo "Running ${i%.cpp}.native"
            time ./${i%.cpp}.native

            echo " "
        done
        cd ..
    fi

    if [[ "$2" == "b" || "$2" == "" ]] ; then
        echo ' '
        echo "Applying optimizations for Q4 (b) and printing their CFG and DOM tree"
        cd b
        for d in ./*/ ; do
            cd "$d"
            i=${d%/}.cpp
            mkdir "unoptimized" -p
            cd "unoptimized"
            ../../../../"$llvm_bin_path"/clang++ -emit-llvm ../$i -S -o ${i%.cpp}.ll
            ../../../../"$llvm_bin_path"/opt ${i%.cpp}.ll -dot-cfg -disable-output
            ../../../../"$llvm_bin_path"/opt ${i%.cpp}.ll -dot-dom -disable-output
            cd ..
            mkdir "optimized" -p
            cd "optimized"
            ../../../../"$llvm_bin_path"/clang++ -O3 -emit-llvm ../$i -S -o ${i%.cpp}.ll
            ../../../../"$llvm_bin_path"/opt ${i%.cpp}.ll -dot-cfg -disable-output
            ../../../../"$llvm_bin_path"/opt ${i%.cpp}.ll -dot-dom -disable-output
            cd ..
            cd ..
        done
        cd ..
    fi

    if [[ "$2" == "c" || "$2" == "" ]] ; then
        echo "Running the different llvm tools"
        cd c
        for i in *.c ; do
            echo "Generating the llvm IR(${i%.c}.ll) for $i using clang emit-llvm"
            ../../"$llvm_bin_path"/clang -emit-llvm $i -S -o ${i%.c}.ll

            echo "Generating the bitcode IR(${i%.c}-llvm-as.bc) using llvm-as from ${i%.c}.ll"
            ../../"$llvm_bin_path"/llvm-as ${i%.c}.ll -o ${i%.c}-llvm-as.bc

            echo "Generating the LLVM IR(${i%.c}-llvm-dis.ll) using llvm-dis from ${i%.c}-llvm-as.bc"
            ../../"$llvm_bin_path"/llvm-dis ${i%.c}-llvm-as.bc -o ${i%.c}-llvm-dis.ll

            echo "Generating the native assembly(${i%.c}.s) from the bitcode IR (${i%.c}-llvm-as.bc) using llc"
            ../../"$llvm_bin_path"/llc ${i%.c}-llvm-as.bc -o ${i%.c}.s

            echo "Executing the bitcode IR(${i%.c}-llvm-as.bc) using JIT using lli"
            ../../"$llvm_bin_path"/clang -emit-llvm $i -c -o ${i%.c}.bc
            ../../"$llvm_bin_path"/lli ${i%.c}.bc
        done
        cd ..
    fi
    exit 0
fi