#include <iostream>
using namespace std;

class basic
{
    public:
    string name;
    int rollnumber;
    
    basic()
    {
        name = "Adam";
        rollnumber = 20;
    }

    // printname is not defined inside class definition
    void printname();
     
    // printroll is defined inside class definition
    void printroll()
    {
        cout << "Roll Number is: " << rollnumber;
    }

    ~basic()
    {
        name = "";
        rollnumber = 0;
    }
};
 
// Definition of printname using scope resolution operator ::
void basic::printname()
{
    cout << "Student name is: " << name;
}
int main() {
     
    basic obj;
    obj.name = "Ben";
    obj.rollnumber = 52;
     
    // call printname()
    obj.printname();
    cout << endl;
     
    // call printid()
    obj.printroll();
    return 0;
}