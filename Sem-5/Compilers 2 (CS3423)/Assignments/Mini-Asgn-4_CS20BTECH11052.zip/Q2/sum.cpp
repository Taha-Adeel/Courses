#include <iostream>
using namespace std;

int main()
{
    int n = 10;
    int dummy = 0;
    int sum = 0;
    int doublesum = 0;
    for(int i=1; i<=n; i++)
    {
        dummy += 1;
        sum += i;
        doublesum += sum;
    }
    cout << dummy << " " << sum << " " << doublesum << endl;
    return 0;
}