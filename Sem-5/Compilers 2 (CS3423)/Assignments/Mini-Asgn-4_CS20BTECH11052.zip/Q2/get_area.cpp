#include <iostream>
using namespace std;

float get_area(float side, int n){
    float area = side * side;
    switch(n){
        case 1:
        case 2:
                area *= 0;
                break;
        
        case 3:
                area *= 1.732 / 4.0;
                break;
        case 4:
                area *= 1;
                break;
        case 5:
                area *= 1.72048;
                break;
        default:
                area = -1;
                
    }

    return area;
}

int main()
{
    int n[] = {3, 4, 5, 6, 7};
    float side = 10;
    float area = 0.0;
    for(int i=0; i<5; i++)
    {
        area = get_area(side, n[i]);
        cout << n[i] << "-->" << area << endl;
    }
    return 0;
}