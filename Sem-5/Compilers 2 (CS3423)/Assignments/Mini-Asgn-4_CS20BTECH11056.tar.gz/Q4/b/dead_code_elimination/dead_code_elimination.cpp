#include <iostream>
using namespace std;

int foo()
{
    int first = 24;
    // dead variable
    bool second = false; 
    int third;
    third = first % 4;
    return first + third;
    //unreachable
    second = true; 
    return 0;
}

int main()
{
    int temp = foo();
    // control flow does not go into loop
    while (false)
    {
        temp += 100;
    }
    return 0;
}