#define LIMIT 1000000 // defining constant macro
// defining simpple macro to add two numbers

#define SUM(a, b) (a + b) 

// setting up variable values
#define SETUP
#ifdef SETUP
    int base = 20;
    int count;
#endif

// functions which run at the start and end of the program
#pragma startup func1
#pragma exit func2

void func1()
{
    count = 0;
}

void func2()
{
    count = -1;
}

// main file
int main()
{
    long long int sum = base;
    // heavy operation
    for(int i=0; i <= LIMIT; i++)
    {
        sum += (long long) i;
        count += SUM(count, 1);
    }

    return 0;
} 