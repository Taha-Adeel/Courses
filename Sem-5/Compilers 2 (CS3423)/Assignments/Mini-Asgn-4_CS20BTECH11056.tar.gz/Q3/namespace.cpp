#include <iostream>
using namespace std;

// first name space
namespace first_space
{
    void func(int n)
    {
        cout << "Sum of first " << n << " naturnal numbers is: " << (n * (n+1)) / 2 << endl;
    }
}
 
// second name space
namespace second_space
{
    void func(int n)
    {
        cout << "Cube of " << n << " is: " << n * n * n << endl;
    }
}

using namespace first_space;
int main ()
{
    // This calls function from first name space.
    func(4);
    second_space::func(9);
    return 0;
}