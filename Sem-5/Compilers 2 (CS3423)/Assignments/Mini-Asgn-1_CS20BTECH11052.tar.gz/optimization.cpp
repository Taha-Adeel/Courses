#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

int main()
{
    srand(time(0));
    vector<int> array;
    int count1 = 0, count2 = 0, i, j;
    for(i = 0; i < 500; i++)
    {
        for(j = 0; j < 500; j++)
        {
            array.push_back(rand() % 20); // pushing random numbers
            count1 += 1;
        }
        count2 += 1;
    }

    long long int rand_sum = 0;
    int four_digits = 0;
    for(i = 0; i < array.size(); i++)
    {
        rand_sum += array[i];
        four_digits += array[i];
        four_digits = four_digits % 10000;
    }
    // printing results
    cout << "Results\n" << count1 << "\n" << count2 << "\n" << rand_sum << "\n" << four_digits << "\n";


    return 0;
}
