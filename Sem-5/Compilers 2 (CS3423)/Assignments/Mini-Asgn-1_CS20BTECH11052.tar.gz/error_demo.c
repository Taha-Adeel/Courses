#include <stdio.h>
#include <math.h>

int main()
{
    long long ans = 0;
    int a, b, c;
    a + b = c;
    for(int i=1; i<=10000000; i++)
    {
        ans += i;
    }
    printf("The result is %lld\n", ans)
}


