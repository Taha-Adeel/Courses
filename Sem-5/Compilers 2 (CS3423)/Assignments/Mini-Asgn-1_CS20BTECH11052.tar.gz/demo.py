res = 0
for i in range(1, 10000001):
    res += i
print("The result is {}\n".format(res))