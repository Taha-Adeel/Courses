a = 0
while a < 10:
    a = a + 1
    if a == 5:
        print("andar se bol bhai", a)
        continue
    if a == 6:
        break
    print(a)
print("done")