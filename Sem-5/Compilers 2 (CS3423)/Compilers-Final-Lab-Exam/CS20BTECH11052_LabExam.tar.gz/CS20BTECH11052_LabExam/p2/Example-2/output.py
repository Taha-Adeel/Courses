a = 10
if a < 20:
    print("a is less than 20")
elif a < 25:
    print("a is less than 25")
else:
    print("a is grater than or equal to 25")