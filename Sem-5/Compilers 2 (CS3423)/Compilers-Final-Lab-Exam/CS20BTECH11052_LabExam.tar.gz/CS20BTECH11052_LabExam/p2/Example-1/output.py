a = 10
b = 10 + (15*20)
c = "two"
d = 'ok'
e = None
f = True
g = False
a = a + 1